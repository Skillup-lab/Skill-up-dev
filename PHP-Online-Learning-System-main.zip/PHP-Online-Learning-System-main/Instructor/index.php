<?php 

include "../Utils/Util.php";
Util::redirect("Profile-View.php", "message", "Welcome");
 ?>