<footer class="main-footer">
      <h4>RCD2013C - EduPulse&copy;2024</h4>
    </footer>
    <script src="../assets/js/bootstrap.bundle.min.js" ></script>
  </body>
</html>